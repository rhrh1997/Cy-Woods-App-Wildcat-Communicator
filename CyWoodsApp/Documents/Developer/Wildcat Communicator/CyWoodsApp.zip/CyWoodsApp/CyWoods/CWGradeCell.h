//
//  CWGradeCell.h
//  CyWoods
//
//  Created by Andrew Liu on 8/17/13.
//  Copyright (c) 2013 Andrew Liu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CWGradeCell : UITableViewCell

@property(nonatomic, weak) IBOutlet UILabel *label;
@property(nonatomic, weak) IBOutlet UILabel *detail;

@end
