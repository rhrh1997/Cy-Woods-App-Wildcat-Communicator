//
//  CWExtraController.h
//  CyWoods
//
//  Created by Andrew Liu on 8/5/13.
//  Copyright (c) 2013 Andrew Liu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CWCalendarController.h"
#import "CWSettingsController.h"

@interface CWExtraController : UIViewController{
    
}

-(void)setup;

@end
