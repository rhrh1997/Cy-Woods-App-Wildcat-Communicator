//
//  CWDetailValueCell.m
//  CyWoods
//
//  Created by Andrew Liu on 8/9/13.
//  Copyright (c) 2013 Andrew Liu. All rights reserved.
//

#import "CWDetailValueCell.h"

@implementation CWDetailValueCell

@end
