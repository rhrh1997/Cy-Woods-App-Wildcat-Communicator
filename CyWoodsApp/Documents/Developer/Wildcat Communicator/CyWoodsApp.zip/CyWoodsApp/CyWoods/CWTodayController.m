//
//  CWTodayController.m
//  CyWoods
//
//  Created by Andrew Liu on 10/28/13.
//  Copyright (c) 2013 Andrew Liu. All rights reserved.
//

#import "CWTodayController.h"

@implementation CWTodayController

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:@"CWTodayController" bundle:nibBundleOrNil];
    if( self ){
        
    }
    return self;
}

@end
